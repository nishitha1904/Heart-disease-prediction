GROUP NUMBER: 14
TOPIC NAME: HEART STROKE PREDICTION
TEAM MEMBERS:
    1) AASRITHA SRIVANI T - BL.EN.U4CSE20185
    2) LOKESH V - BL.EN.U4CSE20190
    3) NISHITHA U - BL.EN.U4CSE20187
    4) SOWGANDHI V - BL.EN.U4CSE20189
DESCRIPTION:
      
          This is a Supervised Learning where we provide inputs and outputs for training the machine. Here, we predict if a person gets heart stroke by analyzing the various attributes that determine a heart stroke. 
The attributes/features are:
1) age
2) sex
3) cp
4) trtbps
5) chol
6) fbs
7) restecg
8) thalachh
9) exng
10) oldpeak
11) slp
12) caa
13) thall
 
We analyzed that each attribute plays a role in determining heart attack. Before training the dataset, we've done the feature reduction and min-max normalization(Data Cleaning). We trained the machine using different classifiers and found the best classifier that fits our model. We used many to techniques to  visualize our data provided in the dataset. 
For ex:
1) ROC-AUC PLOT
2) PRECISION- RECALL PLOT
3) CONFUSION MATRIX
4) CLASSIFICATION REPORT - WHICH TELLS ABOUT PRECISION, RECALL, F SCORE 
5) EXPLORATORY DATA ANALYSIS REPORT
6) K MEANS CLUSTERING .., etc

DATASET SOURCE: UDEMY



                                         

